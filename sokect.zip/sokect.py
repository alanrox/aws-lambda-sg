import socket
import boto3
from botocore.exceptions import ClientError
sgid= ["sg-09775e30757c01f29"]

ec2 = boto3.client('ec2')
client = boto3.client('ec2')

try:
    response = ec2.describe_security_groups(GroupIds=sgid)
    print(response)
except ClientError as e:
    print(e)

ip1=(socket.gethostbyname('google.com.br'))

print(ip1)
mount_cidr=str(ip1)+str("/32")
print(mount_cidr)

sg_rules_list = [{'SecurityGroupRuleId': 'sgr-0625a226c66354d4b','SecurityGroupRule': {'IpProtocol': 'tcp','FromPort': 22,'ToPort': 33333,'CidrIpv4': mount_cidr,'Description': 'deovahome'}}]
response = client.modify_security_group_rules(GroupId='sg-09775e30757c01f29',SecurityGroupRules=sg_rules_list)